function searchTable() {
  const input = document.getElementById('searchInput');
  const filter = input.value.toUpperCase();
  const table = document.getElementById('myTable');
  const rows = table.querySelectorAll('tr');
  let found = false;

  rows.forEach(row => {
    const cells = row.querySelectorAll('td');
    let match = false;

    cells.forEach(cell => {
      const text = cell.textContent || cell.innerText;
      if (text.toUpperCase().indexOf(filter) > -1) {
        match = true;
      }
    });

    if (match) {
      row.style.display = '';
      found = true;
    } else {
      row.style.display = 'none';
    }
  });

  const noResults = document.getElementById('noResults');
  if (!found) {
    noResults.style.display = '';
  } else {
    noResults.style.display = 'none';
  }
}
